# NCX-Installer
The easy to use hub for all my Visual Studio projects. Here to stop you from having to chase new commits and releases.
## Features
- Semi-Auto updating: Will download the latest installer file and run it
- Can download the latest .zip releases of all my projects
- Can download and auto run installers for my programs that support being installed

You do not need to update the program to get the latest releases of my projects! It will get the latest release from GitHub. Updates for NCX-Installer are only pushed to fix bugs and to add options to install newly released programs, that were not presesnt in the previous release.
