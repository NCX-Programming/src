![NCX-Core Logo](https://ninjacheetah-gaming.site/WindowsIconNCXInstaller.png)
# NCX-Installer
![.NET Core](https://github.com/NinjaCheetah/NCX-Installer/workflows/.NET%20Core/badge.svg?branch=master)
![GitHub All Releases](https://img.shields.io/github/downloads/NinjaCheetah/NCX-Installer/total?color=Aqua&label=Downloads)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/NinjaCheetah/NCX-Installer?label=Latest%20Release)
![Discord](https://img.shields.io/discord/714479281312366592?label=Discord)
![Maintenance](https://img.shields.io/maintenance/yes/2020?label=Maintained)
## The easy to use hub for all my Visual Studio projects. Here to stop you from having to chase new commits and releases.
## Features
- Semi-Auto updating: Will download the latest installer file and run it
- Can download and auto run installers for my programs that support being installed

You do not need to update the program to get the latest releases of my projects! It will get the latest release from GitHub. Updates for NCX-Installer are only pushed to fix bugs and to add options to install newly released programs, that were not presesnt in the previous release.
