# NinjaCheetah-Installer
The easy to use hub for all my Visual Studio projects. Here to stop you from having to chase new commits and releases.
