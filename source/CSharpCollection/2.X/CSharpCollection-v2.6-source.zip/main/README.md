# CSharp-Collection-Vol1
This is the follow up project for The Visual Basic Collection Vol1, this time rewritten in C#. It's a collection of smaller programs and games combined into a larger program.
## So, what's included?
- Color Buttons
- C#Calc
- Tic Tac No
- C#Notes
- C#Search
(Information on the Wiki, github.com/NinjaCheetah/CSharp-Collection-Vol1/wiki )
Info also available on my website at: https://ninjacheetah-gaming.site/techprojects/csharpcollection
## What's required?
- The target .NET framework version is currently 4.7.2
- Windows 10 x64 (64-Bit)
