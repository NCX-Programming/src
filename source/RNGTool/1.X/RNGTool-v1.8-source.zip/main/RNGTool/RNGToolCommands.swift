//
//  RNGToolCommands.swift
//  RNGTool
//
//  Created by Campbell on 8/30/21.
//

import SwiftUI

struct RNGToolCommands: Commands {
    var body: some Commands {
        SidebarCommands()
    }
}
