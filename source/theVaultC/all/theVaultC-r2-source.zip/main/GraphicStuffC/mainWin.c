#include <stdio.h>
#include <stdlib.h>
// Declare variables
int menuChoice;

int main(){
    system("cls");
    // Draw main screen
    printf("===============================\n");
    printf("|       'Graphics' Test       |\n");
    printf("|           theVault          |\n");
    printf("|                             |\n");
    printf("|   ");
    // White highlighted section

    printf("\e[0;30m\e[47mPress ENTER to continue");

    printf("   |\n");
    getchar();
}