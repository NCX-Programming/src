//NCX-Core-Lite "functions.h"
//Copyright (C) 2021 NinjaCheetah
//Copyright (C) 2021 NCX-Programming
// Include guard
#ifndef FUNCTIONS_DOT_H
#define FUNCTIONS_DOT_H

// Declare store functions
void clrScrn();
int Download();

#endif /* FUNCTIONS_DOT_H */