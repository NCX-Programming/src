# NCX-Core-Lite
The CLI version of my open-source app store. Here to stop you from having to chase new commits and releases.
