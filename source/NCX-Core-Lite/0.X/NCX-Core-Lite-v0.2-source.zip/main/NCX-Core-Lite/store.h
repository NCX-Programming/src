//NCX-Core-Lite "store.h"
//Copyright (C) 2021 NinjaCheetah
//Copyright (C) 2021 NCX-Programming
// Include guard
#ifndef STORE_DOT_H
#define STORE_DOT_H

// Declare store functions
void ldsifd();
void fkpcmn();
void fkapt();
void vaultc();
void c64tl();

#endif /* STORE_DOT_H */