//NCX-Core-Lite "cli.h"
//Copyright (C) 2021 NinjaCheetah
//Copyright (C) 2021 NCX-Programming
// Include guard
#ifndef GUI_DOT_H
#define GUI_DOT_H

// Declare gui functions
void Store();

#endif /* GUI_DOT_H */